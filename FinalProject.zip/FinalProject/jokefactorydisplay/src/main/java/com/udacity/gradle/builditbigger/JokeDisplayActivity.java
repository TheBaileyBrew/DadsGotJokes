package com.udacity.gradle.builditbigger;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class JokeDisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joke_display);

        String jokeTold = null;
        TextView jokeTextView = findViewById(R.id.display_joke);

        //Get joke intent
        Intent intent = getIntent();
        jokeTold = intent.getStringExtra("this is a joke");

        if (jokeTold != null) {
            jokeTextView.setText(jokeTold);
        } else {
            jokeTextView.setText("Jokes on you... Let's try that again");
        }


    }

}
