package com.udacity.gradle.builditbigger;

import java.util.Random;

public class JokeTeller {

    static Random randomJoke = new Random();
    private static String[] dadJokes = {"Wanna hear a joke about paper? --- Nevermind, it's tearable...",
        "How many apples grow on a tree? --- All of them...",
        "Did you hear about the cheese factory that exploded in France? --- There was nothing left but de Brie...",
        "Why don't skeltons ever go trick or treating? --- Because they have no body ot go with...",
        "Why did the scarecrow win an award? --- Because he was outstanding in his field...",
        "Why do crabs never give to charity? --- Because they're shellfish...",
        "What did the buffalo say to his son when he left for college? --- Bison..."};

    public String tellJoke() {
        return dadJokes[randomJoke.nextInt(dadJokes.length)];
    }
}
