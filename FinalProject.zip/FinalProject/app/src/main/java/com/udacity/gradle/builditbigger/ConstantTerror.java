package com.udacity.gradle.builditbigger;

public class ConstantTerror {

    public final static String JOKE_KEY = "this is a joke";


}
